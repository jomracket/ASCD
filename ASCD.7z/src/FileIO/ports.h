
#pragma pack(push,1)
typedef struct {
  BYTE sampal[16];
  BYTE saareg;
  BYTE saaregs[29];
  BYTE vmpr, hmpr, lmpr, border, line_int, hepr, lepr, lpen, attr, status_reg;
} SamSnapPorts;
#pragma pack(pop)

void getsamports(SamSnapPorts *ports);
void setsamports(SamSnapPorts *ports);


#pragma pack(push,1)
struct ZXSSnapPorts {
  BYTE border; //border + beeper
  BYTE zxpage; //posledne zapsana hodnota na port strankovani
  BYTE ayreg;
  BYTE ayregs[16];
};
#pragma pack(pop)

void getzxsports(ZXSSnapPorts *ports);
void setzxsports(ZXSSnapPorts *ports);

