/* 
 * ASCD : copyright (c) Aley Keprt 2012
 *
 * samsnap.h - Sam Coup� snapshots
 *
 */


#pragma once


bool ScsLoad(class ZipReader &reader);
bool ScsSave(const char *fname);
