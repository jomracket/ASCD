
#pragma pack(push,1)
struct VL1772_Regs {
  BYTE Command;
  BYTE Status;
  BYTE Track;
  BYTE Sector;
  BYTE Data;
  BYTE stepdir;  //stepdir bit: 0=going towards track 79, 1=going towards track 0
};
#pragma pack(pop)


