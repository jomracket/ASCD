ASCD
====
(c) Aley Keprt 1998-2012

ASCD is a mixed source project. In order to incorporate source code from various authors together in this project, I had to drop all the code covered by GNU GPL, as that licence is too limiting and actively forbids combining the code with other code and/or libraries with different licences.

This directory contains just a subset of the complete ASCD source code. You can obtain the rest from the original authors (where applicable). The files here are covered by the GNU LGPL licence.

z80cpu directory contains Z80 CPU emulation library by Ian Collier.

FileIO directory contains various files which describe the fileformats used in ASCD.

FUX is a file format used by Fuxoft Emulator on the Real Sam Coupe. It is used to transfer snapshots from real Sam Coupe to ASCD, and then you can save them to a standard ZX Spectrum snapshot file (i.e. .z80 or .sna).

SCS is a new snapshot file format for Sam Coupe, and is also usable for ZX Spectrum and ZX Spectrum 128. The source code provided here is "work-in-progress", and is subject to changes without notice, until final release of ASCD 0.98.
