/* 
 * ASCD : copyright (c) Aley Keprt 1998-2012
 */


#define WIN32_LEAN_AND_MEAN

#include <windows.h>


BOOL APIENTRY DllMain(HMODULE, DWORD ul_reason_for_call, LPVOID) {

  switch(ul_reason_for_call) {
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}

	return TRUE;
}
