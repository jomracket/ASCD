/* 
 * ASCD : copyright (c) Aley Keprt 1998-2012
 */


#pragma once


typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned long DWORD;
typedef signed char sgn8;


#ifdef WIN32
  #pragma warning(disable:4706) //assignment within conditional expression
  #pragma warning(disable:4244) //conversion X to Y, possible loss of data
  #pragma warning(disable:4127) //conditional expression is constant
#endif
